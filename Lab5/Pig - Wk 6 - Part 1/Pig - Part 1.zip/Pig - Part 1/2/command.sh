

# full command to run script 
pig -x local '/home/cloudera/Desktop/LAB5 Part 1/2/script.pig' 

# execut script in pig
exec script.pig

